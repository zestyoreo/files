import numpy as np
import torch
import pickle as pkl
import torch.nn as nn
import math
import torch.optim as optim
import torchvision
from torch.utils.data import Dataset, DataLoader

torch.manual_seed(100)

def train_val_split(X:torch.Tensor, y1:torch.Tensor, y2:torch.Tensor, train_pc):
    """This function splits the training dataset into train and validation datasets

    Args:
        X (_type_): The input torch 2D tensor
        y1 (_type_): classification target vector tensor
        y2 (_type_): regression target vector tensor
        train_pc (_type_): float \in (0, 1)
    
    Returns:
        X_trn, y1_trn, y2_trn, X_val, y1_val, y2_val
    """

    X_trn, y1_trn, y2_trn, X_val, y1_val, y2_val = None, None, None, None, None, None

    num_samples = len(X)
    indices = np.arange(num_samples)
    num_train_samples = math.floor(num_samples * train_pc)
    train_indices = np.random.choice(indices, num_train_samples, replace=False)
    val_indices = list(set(indices) - set(train_indices))
    X_trn, y1_trn, y2_trn, X_val, y1_val, y2_val = X[train_indices], y1[train_indices],y2[train_indices], X[val_indices], y1[val_indices], y2[val_indices]


    assert X_trn.shape[0] + X_val.shape[0] == X.shape[0]
    return  X_trn, y1_trn, y2_trn, X_val, y1_val, y2_val


def predict_labels(model:nn.Module, X_tst:torch.Tensor):
    """This function makes the predictions for the multi-task model. 

    Args:
        model (nn.Module): trained torch model
        X_tst (torch.Tensor): test Tensor
    Returns:
        y1_preds: a tensor vector containing classificatiopn predictions
        y2_preds: a tensor vector containing regression predictions
    """
    y1_preds, y2_preds = None, None

    y1_preds,y2_preds = model(X_tst)
    y1_preds = torch.round(y1_preds.squeeze())
    y2_preds = y2_preds.squeeze()

    assert len(y1_preds.shape) == 1 and len(y2_preds.shape) == 1
    assert y1_preds.shape[0] == X_tst.shape[0] and y2_preds.shape[0] == X_tst.shape[0]
    assert len(torch.where(y1_preds == 0)[0]) + len(torch.where(y1_preds == 1)[0]) == X_tst.shape[0], "y1_preds should only contain classification targets"
    return y1_preds, y2_preds

## train data
class TrainData(Dataset):
    
    def __init__(self, X_data, y1_data,y2_data):
        self.X_data = X_data
        self.y1_data = y1_data
        self.y2_data = y2_data
        
    def __getitem__(self, index):
        return self.X_data[index], self.y1_data[index],self.y2_data[index]
        
    def __len__ (self):
        return len(self.X_data)

class MTL_model(nn.Module):
    def __init__(self):
        super(MTL_model, self).__init__()
        # Number of input features is 28.
        self.layer_1 = nn.Linear(28, 64) 
        self.layer_2 = nn.Linear(64, 64)
        self.layer_head1 = nn.Linear(64, 32)
        self.layer_head2 = nn.Linear(64, 32)
        self.layer_out1 = nn.Linear(32, 1) 
        self.layer_out2 = nn.Linear(32, 1)
        
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()
        self.dropout1 = nn.Dropout(p=0.1)
        self.dropout2 = nn.Dropout(p=0.1)
        self.batchnorm1 = nn.BatchNorm1d(64)
        self.batchnorm2 = nn.BatchNorm1d(64)
        
    def forward(self, inputs):
        x = self.layer_1(inputs)
        x = self.relu(x)
        x = self.batchnorm1(x)
        x = self.layer_2(x)
        x = self.relu(x)
        x = self.batchnorm2(x)

        x1 = self.layer_head1(x)
        x1 = self.dropout1(x1)
        x1 = self.layer_out1(x1)
        x1 = self.sigmoid(x1)

        x2 = self.layer_head2(x)
        x2 = self.dropout2(x2)
        x2 = self.layer_out2(x2)

        return x1,x2

def train_model(model, criterion_reg, criterion_bin, optimizer, train_dataloader, val_dataloader, epochs=25, lmbda=0.8):
    """returns trained model"""
    print(model)
    # initialize tracker for minimum validation loss
    valid_loss_min = np.Inf
    best_model = model
    for epoch in range(1, epochs):
        train_loss = 0.0
        valid_loss = 0.0

        # train the model #
        y1_trn_correct = 0
        trn_total = 0
        model.train()
        for batch_idx, dta in enumerate(train_dataloader):

            X,y1,y2 = dta[0],dta[1],dta[2]

            # zero the parameter gradients
            optimizer.zero_grad()

            #forward pass
            y1_pred,y2_pred = model(X)    

            # calculate loss
            loss1 = criterion_bin(y1_pred.squeeze(), y1)
            loss2 = criterion_reg(y2_pred.squeeze(), y2)
            loss = loss1 + lmbda*loss2

            #update to calculate acc
            trn_total += X.size()[0]
            y1_pred = torch.round(y1_pred.squeeze())
            y1_trn_correct += torch.sum(torch.eq(y1_pred,y1))

            # back prop
            loss.backward()

            # grad
            optimizer.step()

            train_loss = train_loss + ((1 / (batch_idx + 1)) * (loss.data - train_loss))

        # validate the model #
        y1_val_correct = 0
        val_total = 0
        model.eval()
        for batch_idx, dta in enumerate(val_dataloader):
            
            X,y1,y2 = dta[0],dta[1],dta[2]
            y1_pred,y2_pred = model(X)

            # calculate loss
            loss1 = criterion_bin(y1_pred.squeeze(), y1)
            loss2 = criterion_reg(y2_pred.squeeze(), y2)
            loss = loss1 + lmbda*loss2

            val_total += X.size()[0]
            y1_pred = torch.round(y1_pred.squeeze())
            y1_val_correct += torch.sum(torch.eq(y1_pred,y1))

            valid_loss = valid_loss + ((1 / (batch_idx + 1)) * (loss.data - valid_loss))
        
        #Calculating accuracies
        train_acc1 = y1_trn_correct/trn_total

        val_acc1 = y1_val_correct/val_total

        # print training/validation statistics 
        print('Epoch: {} \tTraining Loss: {:.6f} \tTraining y1 Accuracy: {:.6f} \tValidation Loss: {:.6f} \tValidation y1 Accuracy: {:.6f}'.format(epoch, train_loss, train_acc1, valid_loss, val_acc1))
        
        ## TODO: save the model if validation loss has decreased
        if valid_loss < valid_loss_min:
            best_model = model
            torch.save(model, 'model.pt')
            print('Validation loss decreased ({:.6f} --> {:.6f}).  Saving model ...'.format(
            valid_loss_min,
            valid_loss))
            valid_loss_min = valid_loss
    # return trained model
    return best_model

if __name__ == "__main__":

        
    # Load the dataset
    with open("dataset_train.pkl", "rb") as file:
        dataset_trn = pkl.load(file)
        X_trn, y1_trn, y2_trn = dataset_trn
        X_trn, y1_trn, y2_trn = torch.Tensor(X_trn), torch.Tensor(y1_trn), torch.Tensor(y2_trn)
    with open("dataset_test.pkl", "rb") as file:
        X_tst = pkl.load(file)
        X_tst = torch.Tensor(X_tst)
    
    X_trn, y1_trn, y2_trn, X_val, y1_val, y2_val = train_val_split(X=X_trn, y1=y1_trn, y2=y2_trn, train_pc=0.7)

    model = MTL_model()

    criterion_bin= nn.BCELoss()
    criterion_reg = nn.MSELoss()
    optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

    lmbda = 0.8
    epochs = 100

    BATCH_SIZE = 8
    train_data = TrainData(X_trn,y1_trn,y2_trn)
    val_data = TrainData(X_val,y1_val,y2_val)
    train_loader = DataLoader(dataset=train_data, batch_size=BATCH_SIZE, shuffle=True)
    val_loader =  DataLoader(dataset=val_data, batch_size=BATCH_SIZE, shuffle=True)

    model = train_model(model, criterion_reg, criterion_bin, optimizer, train_loader, val_loader, epochs, lmbda)

    y1_preds, y2_preds = predict_labels(model, X_tst=X_tst)

    # dump the outputs
    with open("output.pkl", "wb") as file:
        pkl.dump((y1_preds, y2_preds), file)
    with open("model.pkl", "wb") as file:
        pkl.dump(model, file)

    dummy_input = torch.randn(10,28)
    input_names = [ "x" ]
    output_names = [ "y1","y2" ]

    torch.onnx.export(model, dummy_input, "mtl_model.onnx", verbose=True, input_names=input_names, output_names=output_names)
    torch.save(model.state_dict(), "model.h5")